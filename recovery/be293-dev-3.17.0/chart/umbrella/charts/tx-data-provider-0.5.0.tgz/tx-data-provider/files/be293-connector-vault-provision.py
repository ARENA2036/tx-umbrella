#!/usr/bin/env python3
"""Verify or initialize connector Vault aliases without exposing values."""
import hmac
import json
import os
from pathlib import Path
import re
import sys
from urllib.error import HTTPError, URLError
from urllib.request import build_opener, HTTPRedirectHandler, Request


MODE = os.environ.get("PROVISION_MODE", "")
WALLET_MODE = os.environ.get("WALLET_MODE", "")
VAULT_URL = os.environ.get("VAULT_URL", "").rstrip("/")
VAULT_FOLDER = os.environ.get("VAULT_FOLDER", "").strip("/")
if MODE not in {"verify", "initialize"}:
    sys.exit("PROVISION_MODE must be verify or initialize")
if WALLET_MODE not in {"identityHub", "stub"}:
    sys.exit("WALLET_MODE must be identityHub or stub")
if not VAULT_URL:
    sys.exit("VAULT_URL is required")
if VAULT_FOLDER and not re.fullmatch(r"[A-Za-z0-9._/-]+", VAULT_FOLDER):
    sys.exit("Invalid Vault folder path")

token = Path("/secrets/auth/token").read_text(encoding="utf-8")
if not re.fullmatch(r"[A-Za-z0-9._-]+", token):
    sys.exit("Invalid Vault token format")


class NoRedirect(HTTPRedirectHandler):
    """Never forward a Vault token to a redirect target."""

    def redirect_request(self, *_args, **_kwargs):
        return None


opener = build_opener(NoRedirect)


def request(alias: str, payload: bytes | None = None) -> tuple[int, bytes]:
    headers = {"X-Vault-Token": token}
    method = "GET"
    if payload is not None:
        headers["Content-Type"] = "application/json"
        method = "POST"
    path = f"{VAULT_FOLDER}/{alias}" if VAULT_FOLDER else alias
    req = Request(f"{VAULT_URL}/v1/secret/data/{path}", data=payload,
                  headers=headers, method=method)
    try:
        with opener.open(req, timeout=30) as response:
            return response.status, response.read()
    except HTTPError as error:
        # Deliberately discard response bodies: Vault diagnostics can contain
        # sensitive context and are not required for lifecycle decisions.
        error.close()
        return error.code, b""
    except (URLError, TimeoutError, OSError):
        return 0, b""


def reconcile_alias(alias: str, filename: str) -> None:
    expected = Path(filename).read_bytes()
    if not expected:
        sys.exit(f"Required external key file is empty: {alias}")
    try:
        expected_text = expected.decode("utf-8")
    except UnicodeDecodeError:
        sys.exit(f"Required external key file is not UTF-8 text: {alias}")

    status, body = request(alias)
    if 200 <= status < 300:
        try:
            actual = json.loads(body)["data"]["data"]["content"].encode("utf-8")
        except (KeyError, TypeError, ValueError, UnicodeEncodeError):
            sys.exit(f"Existing Vault alias has an invalid response: {alias}")
        if not hmac.compare_digest(actual, expected):
            sys.exit(f"Existing Vault alias does not match external custody: {alias}")
        return
    if status != 404:
        sys.exit(f"Vault read failed ({status or 'transport'}): {alias}")
    if MODE != "initialize":
        sys.exit(f"Required Vault alias is missing in verify mode: {alias}")

    payload = json.dumps({"options": {"cas": 0},
                          "data": {"content": expected_text}},
                         separators=(",", ":")).encode("utf-8")
    status, _ = request(alias, payload)
    if not 200 <= status < 300:
        sys.exit(f"Vault CAS initialization failed ({status or 'transport'}): {alias}")


reconcile_alias("tokenSignerPrivateKey", "/secrets/crypto/private-key")
reconcile_alias("tokenSignerPublicKey", "/secrets/crypto/public-key")
reconcile_alias("tokenEncryptionAesKey", "/secrets/crypto/aes-key")
if WALLET_MODE == "stub":
    # IdentityHub owns this alias in acceptance mode. The explicit development
    # stub retains equivalent external-custody and CAS-only behavior.
    reconcile_alias("edc-wallet-secret", "/secrets/crypto/wallet-secret")

print(f"Connector cryptographic aliases {MODE} completed")
