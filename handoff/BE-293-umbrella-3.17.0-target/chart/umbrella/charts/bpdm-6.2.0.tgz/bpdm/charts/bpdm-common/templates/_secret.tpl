---
################################################################################
# Copyright (c) 2021,2024 Contributors to the Eclipse Foundation
#
# See the NOTICE file(s) distributed with this work for additional
# information regarding copyright ownership.
#
# This program and the accompanying materials are made available under the
# terms of the Apache License, Version 2.0 which is available at
# https://www.apache.org/licenses/LICENSE-2.0.
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
# WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
# License for the specific language governing permissions and limitations
# under the License.
#
# SPDX-License-Identifier: Apache-2.0
################################################################################

{{- define "bpdm-common.secret" -}}
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "bpdm.fullname" . }}
type: Opaque
{{- $existingSecret := lookup "v1" "Secret" .Release.Namespace (include "bpdm.fullname" .) }}
{{- if and .Values.recoveryPreserveExistingSecret $existingSecret }}
data:
{{- range $key, $value := $existingSecret.data }}
  {{ $key }}: {{ $value | quote }}
{{- end }}
{{- else }}
stringData:
  secrets.yml: |-
{{- if .Values.applicationSecrets }}
{{- .Values.applicationSecrets | toYaml | nindent 4 }}
{{- end }}
{{- end }}
{{- end -}}